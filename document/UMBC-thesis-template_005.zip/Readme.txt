This template is designed to help you generate a thesis formatted according to the UMBC Grad School requirements using LaTeX.  For information on how to use LaTeX, refer to the numerous help pages and LaTeX tutorials available on the web.

The "thesis.tex" file is the main tex file and the one you should compile using LaTeX.  Additional packages and commands can be added to the header section of "thesis.tex" for use in any of the other tex files.  To add chapters and appendices, clone the "samplechapter.tex" or "sampleAppendix.tex" files, modify their contents, and modify the "thesis.tex" file to include them.

Edit the contents of all other tex files to write your Ph.D. dissertation or Master's thesis.  Good luck!  