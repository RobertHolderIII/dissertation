package holder.elevator;

import holder.GenericPSMap;

public class ElevPSMap extends GenericPSMap<ElevProblem, ElevSolution> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

}
