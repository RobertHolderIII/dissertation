package holder.af.svm;

import holder.PSDimension;
import holder.af.AFProblemInstance;
import holder.sbe.ProblemInstanceMath;

public class AFProblemInstanceMath extends ProblemInstanceMath<AFProblemInstance> {

	@Override
	public AFProblemInstance add(AFProblemInstance template, int value,
			PSDimension dimension) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AFProblemInstance midpoint(AFProblemInstance a, AFProblemInstance b) {
		// TODO Auto-generated method stub
		return null;
	}

}
