package holder.synthetic.vehicle;

import holder.GenericPSMap;

public class VPSMap extends GenericPSMap<VProblemInstance, VSolution> {
	@Override
	public VSolution get(Object vpi){
		return null;
	}
}
