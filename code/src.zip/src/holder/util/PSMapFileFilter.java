package holder.util;

import java.io.File;
import java.io.FileFilter;

public class PSMapFileFilter implements FileFilter {

	
	@Override
	public boolean accept(File f) {
		return f.getName().startsWith("smooth-") && f.getName().endsWith("ser");
	}

}
