package holder.tsp;

import holder.GenericPSMap;

public class TspPSMap extends GenericPSMap<TSPProblemInstance,TSPSolution> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;




}
