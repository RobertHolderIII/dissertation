package holder;

public class ProblemSpaceAnalysis {
	public PSMap psmap;
}
