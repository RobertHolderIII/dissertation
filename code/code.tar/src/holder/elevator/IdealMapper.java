package holder.elevator;

import holder.GenericPSMap;
import holder.elevator.svm.ElevInstancePointConverter;
import holder.elevator.svm.ElevProblemInstanceMath;
import holder.knapsack.KPSMapSolveOrApprox;
import holder.knapsack.KSCApproximator;
import holder.sss.SSSApproximator;
import holder.svm.SVMApproximatorSBE;
import holder.util.ApproximationFileFilter;
import holder.util.GenericAccuracyChecker;
import holder.util.PrintStreamManagement;
import holder.util.Util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteWatchdog;
import org.apache.commons.exec.Executor;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

public class IdealMapper {

	//normalize plan or not
	private static final boolean DO_NORMALIZATION = true;

	private static final int _p01 = 1;
	private static final int _p01_mod = 2;
	private static final int _p01_3d = 13;

	private static final int configuration = _p01_3d;

	private static final int _svm = 12;
	private static final int _sss = 15;
	private static final int approxType = _sss;

	//maximum time we will wait for normalization
	private static final int maxSeconds = 2;
	private static final TimeUnit timeUnit = TimeUnit.SECONDS;


	//------------------------
	//domain pddl lives here
	//-----------------------
	static File DOMAIN_DIR = null;

	static{
		if ("WINDOWS".equals(Util.LOCATION)){
			DOMAIN_DIR = new File("lamaPlanner/work");
		}
		else if ("EB4".equals(Util.LOCATION)){
			DOMAIN_DIR = new File("/home/holder1/vElevator/lamaPlanner/work");
		}
		else if ("UBUNTU_VM".equals(Util.LOCATION)){
			DOMAIN_DIR = new File("/home/holderh1/dissertation/lamaPlanner/work");
		}
	}

	private static final File DOMAIN_FILE = new File(DOMAIN_DIR,"elevator_domain.pddl");

	//------------------------
	//location to put working files
	//------------------------
	public static File SANDBOX_DIR = null;
	static{
		if (configuration == _p01) SANDBOX_DIR = new File(DOMAIN_DIR,"p01");
		else if (configuration == _p01_mod) SANDBOX_DIR = new File(DOMAIN_DIR,"p01-mod");
		else if (configuration == _p01_3d) SANDBOX_DIR = new File(DOMAIN_DIR,"p01-3d");
	}
	//------------------------
	//location of problem pddl
	//------------------------
	public static File PROBLEM_FILE = null;
	static{
		if (configuration == _p01
				|| configuration == _p01_3d){
			PROBLEM_FILE = new File(DOMAIN_DIR, "p01/p01.pddl");
		}
		else if (configuration == _p01_mod){
			PROBLEM_FILE = new File(DOMAIN_DIR, "p01-mod/p01-mod.pddl");
		}
	}

	//--------------------------
	//location of planner
	//--------------------------
	private static File PLANNER_FILE = new File(DOMAIN_DIR,"../seq-sat-lama-2011.tar/seq-sat-lama-2011/plan");


	private static ElevProblemSpace elevPS = null;
	static{
		if (configuration == _p01) elevPS = ElevProblemSpace.PROBLEM_SPACE_P01;
		else if (configuration == _p01_mod) elevPS = ElevProblemSpace.PROBLEM_SPACE_P01_MOD;
		else if (configuration == _p01_3d) elevPS = ElevProblemSpace.PROBLEM_SPACE_P01_3D;
	}


	//------------------------
	//output file template name.  file of the form <OUTPUT_FILENAME>.<number> will
	//be generated
	//------------------------
	private static final String OUTPUT_FILENAME = "elevator_output";

	private static final int MAX_PROCESS_TIME_IN_MS = 60*1000;
	private static ElevPlanParser parser = new ElevPlanParser();
	private static ElevPlanNormalizer normalizer = new ElevPlanNormalizer();

	public static String generateProblemInstancePddl(String template, ElevProblem pi){


		HashMap<String,Integer> templateUpdate = new HashMap<String,Integer>();

		//every passenger entry has either both a starting and ending location or
		//just a ending location.  If it has both, then use the given starting location.
		//if it only has the ending location, then the problem has removed the
		//passenger, and thus we will just start the passenger at the destination
		//location, effectively removing it from planner's consideration

		for (Entry<String, Integer> entry : pi.passengerDestination.entrySet()){
			String pid = entry.getKey();
			Integer startingLocation = pi.passengerInitial.containsKey(pid) ?
					pi.passengerInitial.get(pid):
					pi.passengerDestination.get(pid);
			templateUpdate.put(pid, startingLocation);
		}

		String pddl = template;
		for (Entry<String, Integer> entry : templateUpdate.entrySet()){
			String pid = entry.getKey();
			Integer destFloor = entry.getValue();
			String regex = "passenger-at " + pid + " n\\d*";
			String replacement = "passenger-at " + pid + " n" + destFloor;
			pddl = pddl.replaceFirst(regex, replacement);
		}

		return pddl;
	}


	/**
	 * @param args
	 * @throws IOException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {


		log("System location is " + Util.LOCATION);

		//load problem pddl
		File file = PROBLEM_FILE;
		String templateProblemPddl = FileUtils.readFileToString(PROBLEM_FILE);

		log("found template at " + file);
		//log("template is " + templateProblemPddl);

		ElevPSMap psmap = new ElevPSMap();
		ElevPSMap rawPlans = new ElevPSMap();
		ReversePsmap reversePsmap = new ReversePsmap();

		int i = 0;
		final int total = elevPS.getInstanceCount();
		for (ElevProblem pi : elevPS){
			log("processing instance " + (++i) + " of " + total + ": "+ pi);

			int init0 = pi.getPassengerInitialFloor("p0");
			int init1 = pi.getPassengerInitialFloor("p1");
			int init2 = pi.getPassengerInitialFloor("p2");

			//true to run hack to target specific instances
			if (false){
				if (i != 824){
					continue;
				}
				else {
					ElevPlanNormalizer.DEBUG = true;
					ElevPlanParser.DEBUG = true;
					ElevSolution.DEBUG = true;
					GenericAccuracyChecker.DEBUG = false;//ElevPlanNormalizer.DEBUG;
				}
			}

			if (false){
				ElevPlanNormalizer.DEBUG = //(init0 == 7 && init1 == 14  ||  //p01-mod
					init0 == 7 && init1 == 1;     //p01
			}
			List<String> rawplan;

			File outputDirectory = getOutputDirectory(pi);
			outputDirectory.mkdirs();
			if (outputDirectory.list().length == 0){
				log(outputDirectory + " is empty.  Generating plans");

				//output pddl to filesystem
				File instanceFile = new File(SANDBOX_DIR, "instance" + init0 + "_" + init1 + "_" + init2+ ".pddl");
				String instanceFilename = instanceFile.getAbsolutePath();

				String pddl = generateProblemInstancePddl(templateProblemPddl,pi);

				//output pddl to filesystem

				//log("\n----------------------------------\n");
				//log("instance pddl is " + pddl);
				//log("\n----------------------------------\n");
				log("writing problem instance pddl to " + instanceFilename);

				Writer out = new FileWriter(instanceFilename);
				IOUtils.write(pddl, out);
				out.close();


				try{
					//run planner on files
					outputDirectory.mkdirs();
					FileUtils.cleanDirectory(outputDirectory);
					runPlanner(instanceFilename, outputDirectory);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			else{
				//log(outputDirectory + " has work.  skipping planning");
			}




			//retrieve planner output
			//System.out.println("normalizing plan from " + outputDirectory);
			rawplan = getPlan(outputDirectory);

			//translate into ElevSolution
			log("parsing plan");
			final List<Action> plan = parser.parse(rawplan);

			List<Action> normedPlan = null;
			if (DO_NORMALIZATION){
				log("normalizing plan");
				ExecutorService executor = Executors.newSingleThreadExecutor();
				Future<List<Action>> normalizeTask = executor.submit(new Callable<List<Action>>(){

					@Override
					public List<Action> call() throws Exception {
						return normalizer.normalize( plan );
					}

				});


				try{
					normedPlan = normalizeTask.get(maxSeconds, timeUnit);
				}
				catch(Exception e){
					System.err.println("could not normalize in " + maxSeconds + " " + timeUnit);
					System.err.println(e);
					System.err.println(Arrays.toString(e.getStackTrace()));
					//System.exit(1);
				}
			}//end if do normalization

			ElevSolution solution = new ElevSolution(normedPlan==null?plan:normedPlan);

			if (!solution.isFeasible(pi)){

				log("problem instance:\n" + pi + "\ninfeasible ideal:\n" + solution);



				ElevSolution.DEBUG  = true;
				if (ElevSolution.DEBUG){
					solution.isFeasible(pi);

					//log("exiting system");
					//System.exit(1);

					//break;
				}
				//replace infeasible normed plan with
				//raw plan (which should be feasible)
				System.err.println("replacing normed plan with raw plan");
				solution = new ElevSolution(plan);
			}


			//ElevPlanNormalizer.DEBUG = false;
			//ElevSolution.DEBUG = false;
			//ElevPlanParser.DEBUG = false;
			//GenericAccuracyChecker.DEBUG = false;
			//SVMApproximatorSBE.DEBUG = false;

			psmap.put(pi, solution);
			reversePsmap.put(solution,pi);

			//for (Action pAction : plan){
			//System.out.println(pAction);
			//}

		}

		//end for each problem instance

		//boolean equalityValue = plan12_1.equals(plan11_0);
		//System.out.println("equals should be true.  it is " + equalityValue);

		//boolean equalityValue = plan1_1.equals(plan0_0);
		//System.out.println("equals should be true.  it is " + equalityValue);


		//System.exit(1);

		//		for (ElevProblem epi : psmap.keySet()){
		//			System.out.println(epi);
		//			List<Action> plan = (List<Action>) psmap.get(epi).get(ElevSolution.PLAN);
		//			for (Action action : plan){
		//				System.out.println("\t" + action);
		//			}
		//		}



		Set<ElevSolution> uniqueSolutions = new HashSet<ElevSolution>(psmap.values());
		log("\n---------\nfound " + uniqueSolutions.size() + " unique solutions:");

		if (false) for (ElevSolution s : uniqueSolutions){
			log(s);
			log("=========");
		}

		//print all the plans
		if (false) for (ElevProblem epi : psmap.keySet()){
			log("---------------");
			log(epi.get(ElevProblem.PASSENGER_INIT));
			List<Action> tplan = (List<Action>) psmap.get(epi).get(ElevSolution.PLAN);

			if (tplan == null) System.out.println("null");
			else for (Action line : tplan) System.out.println(line);
		}

		//----------------------------
		//print solution->problem info
		//----------------------------

		if (false){
			log("=========\nsolution->problem info\n============");
			for (ElevSolution s : reversePsmap.keySet()){
				//print out instances
				Collection<ElevProblem> problems = reversePsmap.get(s);
				log(problems.size() + ": " + problems);
				//print out plan
				log(s);

			}
		}


		//---------------------
		//ideal solution sanity check
		//---------------------

		System.err.println("*********FEASIBILITY SANITY CHECK");


		int infeasibleIdealSolutions = 0;
		for (ElevProblem p : psmap.keySet()){
			if (!psmap.get(p).isFeasible(p)){
				infeasibleIdealSolutions++;

				log("problem instance:\n" + p + "\ninfeasible ideal:\n" + psmap.get(p));

				ElevSolution.DEBUG  = false;
				if (ElevSolution.DEBUG){
					psmap.get(p).isFeasible(p);

					log("exiting system");
					System.exit(1);
					break;
				}

			}
		}
		log("IdealMapper: sanity check found " + infeasibleIdealSolutions + " infeasible ideal solutions");

		//System.exit(1);

		//------------------------
		//Do psmap smoothing
		//------------------------

		for (ElevProblem p : psmap.keySet()){
			ElevSolution best = psmap.get(p);
			for (ElevSolution s : uniqueSolutions){
				if (s.isBetterThan(best, p)){
					best = s;
				}
			}
			psmap.put(p,best);
		}


		//----------------------------
		//  Do approximations
		//----------------------------

		log("PS Map approximations");


		KSCApproximator<ElevProblem,ElevSolution> approxer;
		ElevSolver solver = new ElevSolver(psmap);

		//do approximation
		if (approxType == _svm){

			approxer =
				new  SVMApproximatorSBE<ElevProblem, ElevSolution>(
						new ElevInstancePointConverter(),
						new ElevProblemInstanceMath(),
						true);
			approxer.setSolver(solver);

		}
		else{
			approxer = new SSSApproximator<ElevProblem, ElevSolution>(solver);
		}



		File resultsDir = new File(SANDBOX_DIR,"results");
		resultsDir.mkdirs();
		BufferedWriter out = new BufferedWriter(new FileWriter(new File(resultsDir,"svmElevatorOutput3D_" + Util.dateFormat.format(new Date()) + ".txt")));
		out.write("IdealFile\tApproxFile\tSampleSize\tAlphaValue\tMatchPercent\tAvgPctUtilityLoss");
		out.newLine();

		final char TAB = '\t';
		final double UNIT = 100000.0;

		int[] fullSampleSet = new int[]{10,20,30,40,50,60,70,80,90,100,200,300,400,500,600,700,800,900,1000,10000,20000,50000};
		int[] smallSampleSet = new int[]{50,100,500,1000,5000,10000,50000};
		int[] half = new int[]{50000};
		int[] whole = new int[]{100000};
		int[] pointOhOne = new int[]{1000};
		int[] pointOhFive = new int[]{5000};

		String[] alphaValues = new String[]{".1", ".3", ".5", ".7", ".9"};
		//String[] alphaValues = new String[]{".5"};
		for (int run = 0; run < 3; run++){
			for (int samplesPer100k: smallSampleSet){
				for (String alphaValue : alphaValues){
					approxer.addProperty(KPSMapSolveOrApprox.ALPHA, alphaValue);
					GenericPSMap<ElevProblem,ElevSolution> approxMap = approxer.generate(elevPS, samplesPer100k/UNIT);
					GenericAccuracyChecker<ElevProblem,ElevSolution> ac = new GenericAccuracyChecker<ElevProblem,ElevSolution>(psmap, approxMap);
					out.write("in memory" + TAB + "in memory" + TAB + (samplesPer100k/UNIT) + TAB + alphaValue + ac.getMatchFraction() + TAB + ac.getAveragePercentUtilityLoss());
					out.newLine();
					out.flush();
				}
			}
		}
		out.close();
	}//end main

	public static File getOutputDirectory(ElevProblem pi) {
		int init0 = pi.getPassengerInitialFloor("p0");
		int init1 = pi.getPassengerInitialFloor("p1");
		int init2 = pi.getPassengerInitialFloor("p2");
		return new File(SANDBOX_DIR, init0 + "_" + init1 + "_" + init2);
	}


	static List<String> getPlan(File outputDirectory) throws FileNotFoundException, IOException {
		if (outputDirectory == null || !outputDirectory.exists() || !outputDirectory.isDirectory() || outputDirectory.listFiles() == null){
			log("IdealMapper.getPlan: problem with output directory");
			log("\toutputDirectory="+outputDirectory);
			log("\toutputDirectory exists="+outputDirectory.exists());
			log("\toutputDirectory is directory="+outputDirectory.isDirectory());
			log("\toutputDirectory files="+outputDirectory.listFiles());
		}


		//look for files of the form <outputDirectory>/<OUTPUT_FILENAME>.<number>
		//and find the highest number
		int highest = 0;
		File highestFile = null;

		for (File file : outputDirectory.listFiles()){
			if (file.isFile()){

				int dotIndex = file.getName().indexOf('.');

				try{
					int number = Integer.parseInt(file.getName().substring(dotIndex+1));


					if (number > highest){
						highest = number;
						highestFile = file;
					}
				}
				catch(NumberFormatException e){
					log("IdealMapper.getPlan could not parse name of file at " + file.getAbsolutePath());
				}
			}
			else{
				log("IdealMapper.getPlan skipping non-file at " + file.getAbsolutePath());
			}
		}
		log("IdealMapper.getPlan: returning plan from file " + highestFile.getAbsolutePath());

		FileReader in = new FileReader(highestFile);
		List<String> plan = IOUtils.readLines(in);
		in.close();
		return plan;


	}

	public static void runPlanner(String instanceFilename, File outputDirectory) throws IOException, InterruptedException{

		outputDirectory.mkdirs();
		String outputTarget = new File(outputDirectory, OUTPUT_FILENAME).getAbsolutePath();

		File plannerExecutable = PLANNER_FILE;
		if (!plannerExecutable.exists()){
			throw new FileNotFoundException(plannerExecutable.getAbsolutePath());
		}
		if (!DOMAIN_FILE.exists()){
			throw new FileNotFoundException(DOMAIN_FILE.getAbsolutePath());
		}
		if (!new File(instanceFilename).exists()){
			throw new FileNotFoundException(instanceFilename);
		}

		CommandLine command = new CommandLine(plannerExecutable.getAbsolutePath());
		command.addArgument(DOMAIN_FILE.getAbsolutePath());
		command.addArgument(instanceFilename);
		command.addArgument(outputTarget);
		log("runPlanner: running " + command.toString());

		Executor exec = new DefaultExecutor();
		ExecuteWatchdog watchdog = new ExecuteWatchdog(MAX_PROCESS_TIME_IN_MS);
		//exec.setWatchdog(watchdog);


		PrintStreamManagement.closeOutputStream();
		int exitCode = exec.execute(command);
		PrintStreamManagement.openOutputStream();

		log("runPlanner: exit code was " + exitCode);
		if (watchdog.killedProcess()){
			log("runPlanner: process took too long and was killed");
		}
	}

	public static void log(Object msg){
		System.err.println(msg);
	}

	private static class ReversePsmap extends HashMap<ElevSolution,TreeSet<ElevProblem>>{
		public void put(ElevSolution s, ElevProblem p){
			TreeSet<ElevProblem> problems = this.get(s);
			if (problems == null){
				problems = new ElevProblemTreeSet();
				this.put(s,problems);
			}
			problems.add(p);
		}
	}
	private static class ElevProblemTreeSet extends TreeSet<ElevProblem>{
		private static final ElevProblemComparator ec= new ElevProblemComparator();
		public ElevProblemTreeSet(){
			super(ec);
		}
	}
	private static class ElevProblemComparator implements Comparator<ElevProblem>{

		@Override
		public int compare(ElevProblem o1, ElevProblem o2) {
			return getPassInitString(o1).compareTo(getPassInitString(o2));
		}
		@SuppressWarnings("unchecked")
		private String getPassInitString(ElevProblem p){
			StringBuilder sb = new StringBuilder();
			Map<String,Integer> passInit = (Map<String,Integer>)(p.get(ElevProblem.PASSENGER_INIT));
			Set<String> keySet = passInit.keySet();
			SortedSet<String> keys = new TreeSet<String>( keySet );
			for (String key : keys){
				sb.append(key+passInit.get(key));
			}
			return sb.toString();
		}

	}


}
