package holder.elevator;

import holder.elevator.ContactInfo.DestinationType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class ElevPlanNormalizer {


	public static boolean DEBUG = false;
	private final List<String> elevatorIds = new ArrayList<String>();
	private int currentElevatorIdIndex;
	/**
	 * map from elevator id to what is blocking it
	 */
	private final Map<String,List<Block>> blocksMap = new HashMap<String,List<Block>>();

	/**
	 * map from elevator id to Action objects that it is blocking
	 */
	private final Map<String,List<Action>> blockedActionsMap = new HashMap<String,List<Action>>();
	public ElevPlanNormalizer(){
		//empty
	}

	private String getNextElevatorId(){
		currentElevatorIdIndex = (currentElevatorIdIndex+1)%elevatorIds.size();
		return getCurrentElevatorId();
	}
	private String getCurrentElevatorId(){
		return elevatorIds.get(currentElevatorIdIndex);
	}

	private void init(List<Action> rawPlan){
		blocksMap.clear();
		blockedActionsMap.clear();
		//generate elevator ids
		Set<String> foundElevatorIds = new HashSet<String>();
		for (Action a : rawPlan){
			foundElevatorIds.add(a.elevatorId);
		}
		elevatorIds.clear();
		elevatorIds.addAll(foundElevatorIds);
		Collections.sort(elevatorIds);
		currentElevatorIdIndex = 0;
	}

	public List<Action> normalize(List<Action> rawPlan){

		if (DEBUG){
			System.err.println("\tNormalizing plan");
			for (Action a : rawPlan){
				System.err.println(a);
			}
		}

		init(rawPlan);

		if (DEBUG) System.err.println("\tfound elevatorIds: " + elevatorIds);

		List<Action> sandboxPlan = new ArrayList<Action>(rawPlan);

		// not going to expand contact info because we want to make sure
		// that when we block on a specific ContactInfo that we block
		// on the whole action
		//		sandboxPlan = expandContactInfoLists(sandboxPlan);
		//
		//		if (DEBUG) System.err.println("\tExpanded contact information");
		//		for (Action action : sandboxPlan){
		//			if (DEBUG) System.err.println(action);
		//		}

		List<Action> normalizedPlan = new ArrayList<Action>();


		while(!sandboxPlan.isEmpty()){
			String eid = getCurrentElevatorId();
			int actionIndex;
			Action action = null;

			if (DEBUG) System.err.println("\tsearching for actions of elevator " + eid);

			//put as many current elevator id actions as
			//possible into the normalized plan
			while( (actionIndex = findActionWithElevator(eid,sandboxPlan)) > -1 ){

				action = sandboxPlan.get(actionIndex);
				if (DEBUG) System.err.println("\tprocessing action:\n" + action);

				normalizedPlan.add(action);
				sandboxPlan.remove(actionIndex);

				//if something was waiting for this action, then free the something
				if (isBeingWaitedFor(action)){
					removeWaitForAction(action);
				}

				//if we require an XFER_SEND then
				//
				if (actionContainsXferReceive(action)){
					break;
				}
			}//end while processing actions for specific elevator

			//if we stopped because we ran out of actions
			//for this elevator then do nothing
			if (actionIndex == -1){
				//do nothing
			}
			else{
				do{

					//otherwise this elevator is blocked

					//search ahead to find the elevator that this
					//TRANSFER is waiting on
					addBlock(eid,action,sandboxPlan);

					actionIndex = findActionWithElevator(eid,sandboxPlan);
					action = actionIndex < 0? null : sandboxPlan.get(actionIndex);
					if (action != null && action.contactId.first().destinationType.isTransferType()){
						if (DEBUG) System.err.println("\tprocessing TRANSFER action:\n" + action);
						normalizedPlan.add(action);
						sandboxPlan.remove(actionIndex);
					}
				}while(action != null && action.contactId.first().destinationType.isTransferType());
			}

			if (DEBUG) System.err.println("stuff that is blocked: " + blocksMap);
			if (DEBUG) System.err.println("stuff we are waiting for: " + this.blockedActionsMap);

			//get next non-blocking elevatorId
			do{
				eid = getNextElevatorId();
			}while(isBlocked(eid));


		}//end while sandbox plan is not empty
		return normalizedPlan;
	}


	private boolean actionContainsXferReceive(Action action){
		for (ContactInfo ci : action.contactId){
			if (ci.destinationType == DestinationType.XFER_RECEIVE){
				return true;
			}
		}
		return false;
	}

	private void addBlock(String elevatorIdThatIsBlocked,
			Action actionThatIsBlocked,
			List<Action> plan){

		List<Block> blocks = blocksMap.get(elevatorIdThatIsBlocked);
		if (blocks == null){
			blocks = new ArrayList<Block>();
			blocksMap.put(elevatorIdThatIsBlocked, blocks);
		}




		//find action that has some other elevator
		//coming to this same floor for the same passenger
		for (ContactInfo blockedCi : actionThatIsBlocked.contactId){
			if (blockedCi.destinationType != DestinationType.XFER_RECEIVE) continue;

			//determine which future contactInfo would satisfy this blocked action
			for (Action futureAction : plan){
				for (ContactInfo futureCi : futureAction.contactId){

					if (futureCi.destinationType != DestinationType.XFER_SEND) continue;

					if (futureAction.destination == actionThatIsBlocked.destination &&
							futureCi.passengerId.equals(blockedCi.passengerId)){

						//record the actions that are waiting on this elevator
						List<Action> blockedActions = this.blockedActionsMap.get(futureAction.elevatorId);
						if (blockedActions == null){
							blockedActions = new ArrayList<Action>();
							blockedActionsMap.put(futureAction.elevatorId, blockedActions);
						}
						blockedActions.add(actionThatIsBlocked);

						Block block = new Block(futureAction.elevatorId,actionThatIsBlocked.destination,blockedCi.passengerId);
						blocks.add(block);


						if (DEBUG) System.err.println("\televator " + elevatorIdThatIsBlocked + " is blocking on elevator "
								+ block.elevatorId + " at floor " + block.floor + " for passenger " + blockedCi.passengerId);
					}
				}//end for each future contact info
			}//end for each future action
		}
	}

	private boolean actionHasContactInfoWithPassengerId(Action action, String passId){
		for (ContactInfo info : action.contactId){
			if (info.passengerId.equals(passId)){
				return true;
			}
		}
		return false;
	}


	private void removeWaitForAction(Action actionBeingWaitedFor){
		List<Action> blockedActions = blockedActionsMap.get(actionBeingWaitedFor.elevatorId);
		for (int i = blockedActions.size()-1; i >-1;i--){
			Action blockedAction = blockedActions.get(i);

			//System.err.println("removeWaitForAction: blockedAction.passengerId="+blockedAction.passengerId);
			//System.err.println("removeWaitForAction: actionBeingWaitedFor.passengerId="+actionBeingWaitedFor.passengerId);

			if (blockedAction.destination == actionBeingWaitedFor.destination){

				//this used to be part of the if clause, but don't think it's actually needed
				//	&& blockedAction.contactId.first().passengerId.equals(actionBeingWaitedFor.contactId.first().passengerId)){

				//remove record of something waiting on this elevator
				blockedActions.remove(i);


				//remove record if this elevator waiting for something
				List<Block> blocks = blocksMap.get(blockedAction.elevatorId);
				for (int blockI=blocks.size()-1;blockI>-1;blockI--){
					//System.err.print("blocks size="+blocks.size());
					//System.err.println("  blockI="+blockI);

					Block block = blocks.get(blockI);
					if (block.elevatorId.equals(actionBeingWaitedFor.elevatorId)
							&& block.floor == actionBeingWaitedFor.destination
							&& actionHasContactInfoWithPassengerId(actionBeingWaitedFor, block.passengerId)){
						Block removedBlock = blocks.remove(blockI);
						if (DEBUG) System.err.println("\tremoving block " + removedBlock);
					}
				}

			}//end if destinations match
		}

	}

	private boolean isBeingWaitedFor(Action recentAction){
		if (!blockedActionsMap.containsKey(recentAction.elevatorId)){
			return false;
		}
		else{
			//get all actions that are blocked by this elevator
			List<Action> actions = blockedActionsMap.get(recentAction.elevatorId);
			if (actions.isEmpty()){
				return false;
			}
			else{
				for (Action blockedAction : actions){
					//see if blocked action was waiting for
					//elevator on recentAction's floor

					//System.err.println("isBeingWaitedFor: blockedAction.passengerId="+blockedAction.passengerId);
					//System.err.println("isBeingWaitedFor: recentAction.passengerId="+recentAction.passengerId);


					if (blockedAction.destination == recentAction.destination){
						return true;
					}
				}
				return false;
			}
		}
	}

	private int findActionWithElevator(String elevId, List<Action> plan){
		for (int i = 0; i<plan.size();i++){
			if (plan.get(i).elevatorId.equals(elevId)){
				return i;
			}
		}
		return -1;
	}


	private boolean isBlocked(String elevatorId){
		return blocksMap.containsKey(elevatorId) && !blocksMap.get(elevatorId).isEmpty();
	}


	private static List<String> testPlan = Arrays.asList(
			"(board p0 slow1-0 n8 n0 n1)",
			"(move-down-slow slow1-0 n8 n6)",
			"(move-down-slow slow0-0 n6 n5)",
			"(board p2 slow0-0 n5 n0 n1)",
			"(leave p0 slow1-0 n6 n1 n0)",
			"(board p0 fast0 n6 n0 n1)",
			"(move-up-slow slow0-0 n5 n6)",
			"(leave p0 fast0 n6 n1 n0)",
			"(leave p2 slow0-0 n6 n1 n0)",
			"(board p2 slow1-0 n6 n0 n1)",
			"(board p0 slow0-0 n6 n0 n1)",
			"(move-up-slow slow1-0 n6 n7)",
			"(board p1 slow1-0 n7 n1 n2)",
			"(leave p2 slow1-0 n7 n2 n1)",
			"(move-down-slow slow0-0 n6 n3)",
			"(leave p0 slow0-0 n3 n1 n0)",
			"(move-up-slow slow1-0 n7 n11)",
			"(leave p1 slow1-0 n11 n1 n0)");

	private static List<String> testPlan2 = Arrays.asList(
	"(move-down-slow slow1-0 n8 n7)",
	"(board p0 slow1-0 n7 n0 n1)",
	"(move-down-slow slow1-0 n7 n6)",
	"(leave p0 slow1-0 n6 n1 n0)",
	"(board p0 slow0-0 n6 n0 n1)",
	"(move-down-slow slow0-0 n6 n3)",
	"(leave p0 slow0-0 n3 n1 n0)",
	"(move-down-slow slow0-0 n3 n0)",
	"(board p1 slow0-0 n0 n0 n1)",
	"(board p2 slow0-0 n0 n1 n2)",
	"(move-up-slow slow0-0 n0 n6)",
	"(leave p2 slow0-0 n6 n2 n1)",
	"(board p2 slow1-0 n6 n0 n1)",
	"(leave p1 slow0-0 n6 n1 n0)",
	"(board p1 slow1-0 n6 n1 n2)",
	"(move-up-slow slow1-0 n6 n7)",
	"(leave p2 slow1-0 n7 n2 n1)",
	"(move-up-slow slow1-0 n7 n11)",
	"(leave p1 slow1-0 n11 n1 n0)");


	public static void main(String[] args){
		ElevPlanParser parser = new ElevPlanParser();
		ElevPlanParser.DEBUG = true;
		List<String> rawPlan = testPlan2;//ElevPlanParser.instance6_0;
		List<Action> plan = parser.parse(rawPlan);

		ElevPlanNormalizer.DEBUG = true;
		List<Action> normalizedPlan = new ElevPlanNormalizer().normalize(plan);
		System.out.println("----raw plan");
		for (String action : rawPlan){
			System.out.println(action);
		}
		System.out.println("----parsed plan");
		for (Action action : plan){
			System.out.println(action.toString(true));
		}
		System.out.println("----normalized plan");
		for (Action action : normalizedPlan){
			System.out.println(action.toString(true));
		}
	}


	private class Block{
		@Override
		public String toString() {
			return "Block [elevatorId=" + elevatorId + ", floor=" + floor + " passId=" + passengerId +"]";
		}
		public String elevatorId;
		public int floor;
		public String passengerId;

		public Block(String elevatorId, int floor, String passId) {
			this.elevatorId = elevatorId;
			this.floor = floor;
			this.passengerId = passId;
		}

	}

}
