package holder;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class GenericPSMap<P extends GenericProblemInstance, S extends GenericSolution> extends HashMap<P,S> implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;


	private final Map<Object,Object> metadata = new HashMap<Object,Object>();


	public enum GenerationMethod {IDEAL, SAMPLING_CLASSIFICATION, SOLUTION_BORDER_ESTIMATION};

	private GenericProblemSpace<P> problemSpace;
	private long timeToCreateInSeconds;

	private long timeStarted;
	private long timeEnded;

	public void markStart(){
		timeStarted = System.currentTimeMillis();
	}



	public void markEnd(){
		timeEnded = System.currentTimeMillis();
		timeToCreateInSeconds = (timeEnded-timeStarted)/1000;
	}

	public long getTimeToCreateInSeconds(){
		return timeToCreateInSeconds;
	}

	//IDEAL
	//none


	public GenericProblemSpace<P> getProblemSpace(){
	    return problemSpace;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	/**
	 * @return the timeStarted
	 */
	public long getTimeStarted() {
		return timeStarted;
	}

	/**
	 * @param timeStarted the timeStarted to set
	 */
	public void setTimeStarted(long timeStarted) {
		this.timeStarted = timeStarted;
	}



	/**
	 * @param problemSpace the problemSpace to set
	 */
	public void setProblemSpace(GenericProblemSpace<P> problemSpace) {
		this.problemSpace = problemSpace;
	}



	public void addMetadata(Object key, Object value) {
		metadata.put(key,value);

	}
	public Object getMetadata(Object key){
		return metadata.get(key);
	}
}
