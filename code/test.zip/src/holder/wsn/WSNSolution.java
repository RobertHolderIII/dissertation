package holder.wsn;

import holder.GenericProblemInstance;
import holder.GenericSolution;

public class WSNSolution extends GenericSolution {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double getUtility(GenericProblemInstance gpi) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}



}
