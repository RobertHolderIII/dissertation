package holder.sc;

import java.awt.Rectangle;

import holder.PSMap;

public class PSMapALSC {

	/**
	 * @param args
	 */
	PSMap generate(Rectangle problemSpace){
		
		//do init sampling
		//calculate solutions
		
		//while there is information to be gained
			//for each potential solution A
				//chose addl samples based on information gain (A vs not A)
				//calculate solutions
		
		
		//classify most confident unknown solutions

		return null;
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
