package holder.sc;

import holder.ProblemInstance;
import holder.Solution;

public class DistanceSquaredBasedSolutionScoreUpdater implements
		SolutionScoreUpdater {

	@Override
	public Double update(ProblemInstance solvedInstance,
			Solution solvedInstanceSolution, Double currentSolutionScore,
			ProblemInstance unsolvedInstance) {
		
		double start = currentSolutionScore == null?0:currentSolutionScore;
		start -= solvedInstance.getPoint().distanceSq(unsolvedInstance.getPoint());
		return start;
	}

}
