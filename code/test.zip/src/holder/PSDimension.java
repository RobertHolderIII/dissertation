package holder;

import holder.util.Domain;

public class PSDimension{
	public Domain domain;
	public String name;
	public PSDimension(String name, Domain instances) {
		this.name = name;
		this.domain = instances;
	}

	public PSDimension(Domain instances){
		this(instances.label,instances);
	}
}