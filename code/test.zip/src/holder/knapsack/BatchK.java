package holder.knapsack;

import holder.GenericPSMap;
import holder.PSDimension;
import holder.ideal.GenericIdealPSMapper;
import holder.util.Domain;
import holder.util.GenericUtil;
import hu.pj.obj.Item;

import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class BatchK {

	public enum FeasibilityCheckMode {NONE, UTILITY_CALC, POLLING_SELECTION}
	public static final FeasibilityCheckMode feasCheckMode = FeasibilityCheckMode.UTILITY_CALC;

	private enum Mode {DEBUG_KNAPSACK, SMALL_KNAPSACK, TYPICAL_KNAPSACK};
	private final static Mode mode = Mode.TYPICAL_KNAPSACK;

	public static int MAX_WEIGHT;
	public static int minW;
	public static int maxW;
	public static int minV;
	public static int maxV;
	static{
		init();
	}

	//TODO hack
	public static KProblemSpace region = new KProblemSpace(getTemplate()){
		/**
		 *
		 */
		private static final long serialVersionUID = 1L;

		{
			put( new PSDimension(KProblemInstance.WEIGHT,new Domain(KProblemInstance.WEIGHT,minW, maxW, 1)));
			put( new PSDimension(KProblemInstance.VALUE, new Domain(KProblemInstance.VALUE,minV, maxV, 1)));
		}
	};
	//TODO hack
	public static Rectangle regionRectangle;

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		final boolean saveIncrementally = false;

		GenericIdealPSMapper<KProblemInstance,KSolution> mapper = new GenericIdealPSMapper<KProblemInstance,KSolution>();
		KSolver solver = new KSolver();

		String fname = "psmap-k_" + System.currentTimeMillis() + ".ser";
		File dir = new File("C:\\Documents and Settings\\holderh1\\My Documents\\umbc\\dissertation\\data\\k");
		File outFile = new File(dir, fname);

		//save incrementally
		if (saveIncrementally){
			String incFname = fname + ".part";
			mapper.setIncrementalSaveFile(new File(dir, incFname));
		}


		//do the hard work
		System.out.println("BatchK.main: generating ideal map");
		GenericPSMap<KProblemInstance, KSolution> psmap = mapper.generatePSMap(getInstances(), solver);
		GenericUtil.savePSMap(psmap, outFile);
		outFile.setReadOnly();
		mapper.deleteIncrementalFile();

		KVisualizer vis = new KVisualizer();
		regionRectangle = new Rectangle(minW,minV,maxW-minW+1,maxV-minV+1);
		vis.setVisible(true);
		vis.display(regionRectangle, null, psmap, "Knapsack-ideal", null);

		//do approximation
		System.out.println("BatchK.main: generating approximate map");
		KSCApproximator<KProblemInstance, KSolution> approximator = new KPSMapSolveOrApprox<KProblemInstance, KSolution>();
		KSolutionScoreUpdater<KProblemInstance, KSolution> updaterClass = new KDistanceBasedSolutionScoreUpdater();
		solver.setOracle(psmap);
		approximator.setSolver(solver);
		approximator.setInitialPollingRadius(15);
		approximator.setSolutionScoreUpdater(updaterClass);
		approximator.addProperty(KPSMapSolveOrApprox.ALPHA, "0.2");
		new KBatchSC().runBatchSC(dir, new KDistanceBasedSolutionScoreUpdater(), new File[]{outFile}, solver, approximator);


	}//end main


	public static void init(){
		System.out.println("BatchK.init:  running in mode " + mode);
		if (mode == Mode.DEBUG_KNAPSACK){
			MAX_WEIGHT = 40;
			minW = 1;
			maxW = 2;
			minV = 1;
			maxV = 2;
		}
		else if (mode == Mode.SMALL_KNAPSACK){
			MAX_WEIGHT = 40;
			minW = 1;//10;
			maxW = 100;//40;
			minV = 1;
			maxV = 100;//20;
		}
		else{ //mode == Mode.TYPICAL_KNAPSACK
			MAX_WEIGHT = 400;
			minW = 1;
			maxW = 100;
			minV = 1;
			maxV = 100;
		}
	}

	private static KProblemInstance getTemplate(){
		ArrayList<Item> items = new ArrayList<Item>();
		items.add(new Item("map", 9, 150));
		items.add(new Item("compass", 13, 35));
		items.add(new Item("water", 153, 200));
		items.add(new Item("sandwich", 50, 160));
		items.add(new Item("glucose", 15, 60));
		items.add(new Item("tin", 68, 45));
		items.add(new Item("banana", 27, 60));
		items.add(new Item("apple", 39, 40));
		items.add(new Item("cheese", 23, 30));
		items.add(new Item("beer", 52, 10));
		items.add(new Item("suntan cream", 11, 70));
		items.add(new Item("camera", 32, 30));
		items.add(new Item("t-shirt", 24, 15));
		items.add(new Item("trousers", 48, 10));
		items.add(new Item("umbrella", 73, 40));
		items.add(new Item("waterproof trousers", 42, 70));
		items.add(new Item("waterproof overclothes", 43, 75));
		items.add(new Item("note-case", 22, 80));
		items.add(new Item("sunglasses", 7, 20));
		items.add(new Item("towel", 18, 12));
		items.add(new Item("socks", 4, 50));
		items.add(new Item("book", 30, 10));
		KProblemInstance i = new KProblemInstance(items, MAX_WEIGHT);
		return i;
	}

	private static ArrayList<KProblemInstance> getInstances(){
		return getInstances(MAX_WEIGHT);
	}
	private static ArrayList<KProblemInstance> getInstances(int maxWeight){

		ArrayList<KProblemInstance> instances = new ArrayList<KProblemInstance>((maxW-minW+1)*(maxV-minV+1));

		KProblemInstance template = getTemplate();


		for (int w = minW; w<=maxW; w++){
			for (int v = minV; v <= maxV; v++){
				KProblemInstance pi = (KProblemInstance) template.clone();
				pi.put(KProblemInstance.VARIABLE,new Item(KProblemInstance.VARIABLE, w, v));
				instances.add(pi);
			}
		}

		return instances;
	}



}
