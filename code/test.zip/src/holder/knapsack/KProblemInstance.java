package holder.knapsack;

import holder.GenericProblemInstance;
import hu.pj.obj.Item;

import java.util.Collection;
import java.util.HashSet;

public class KProblemInstance extends GenericProblemInstance {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public static final String WEIGHT = "weight";
	public static final String VALUE = "value";
	public static final String VARIABLE = "VARIABLE";


	//if addl class members are added, make sure that super.clone()
	//will account for them, or override super.clone()

	public KProblemInstance(Collection<Item> items, int maxWeight) {
		for (Item item : items){
			this.put(item.getName(), item);
		}
		this.put(WEIGHT, maxWeight);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

//	@Override
//	public String toString(){
//		return "KProblemInstance[" + items.toString() + "]";
//	}

//	@Override
//	public boolean equals(Object o){
//		if (o == null) return false;
//		if (this == o) return true;
//		if (o instanceof KProblemInstance){
//			KProblemInstance other = (KProblemInstance)o;
//			return this.items.values().equals(other.items.values());
//		}
//		else{
//			return false;
//		}
//	}
//
//	@Override
//	public int hashCode(){
//		return maxWeight + items.hashCode();
//	}

	@Override
	public double distance(GenericProblemInstance other) {
		Collection<String> allKeys = new HashSet<String>(this.keySet());
		allKeys.addAll(other.keySet());

		double sumOfSquares = 0;

		for (String key : allKeys){
			Object obj = this.get(key);
			if (obj instanceof Item){
				Item i = (Item)this.get(key);
				Item oi = (Item)other.get(key);
				sumOfSquares += Math.pow((i==null?0:i.getValue())- (oi==null?0:oi.getValue()), 2);
				sumOfSquares += Math.pow((i==null?0:i.getWeight())- (oi==null?0:oi.getWeight()), 2);
			}
			else{
				Integer i = (Integer)this.get(key);
				Integer oi = (Integer)other.get(key);
				sumOfSquares += Math.pow((i==null?0:i)- (oi==null?0:oi), 2);
				sumOfSquares += Math.pow((i==null?0:i)- (oi==null?0:oi), 2);
			}
		}

		return Math.sqrt(sumOfSquares);
	}


	public int getMaxWeight(){
		Integer maxWeight = (Integer)get(KProblemInstance.WEIGHT);
		if (maxWeight == null){
			throw new RuntimeException("undefined weight contraint");
		}
		else{
			return maxWeight;
		}
	}

//	/**
//	 * change individual weight and value keys to one item
//	 */
//	public void doHack(){
//		put("variable", new Item("variable",(Integer)get(WEIGHT),(Integer)get(VALUE)));
//		remove(WEIGHT);
//		remove(VALUE);
//	}

}


