package holder.knapsack;

import holder.GenericProblemInstance;
import holder.GenericSolution;

import java.io.Serializable;

public interface KSolutionScoreUpdater<P extends GenericProblemInstance, S extends GenericSolution> extends Serializable {

	Double update(P solvedInstance,
			S solvedInstanceSolution, Double currentSolutionScore,
			P unsolvedInstance);

}
