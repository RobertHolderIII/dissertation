package holder.knapsack;

import holder.GenericPSMap;
import holder.GenericProblemInstance;
import holder.GenericSolution;
import holder.Solution;
import holder.sbe.BorderIntersection;
import holder.sbe.PSMapCalculator;
import holder.sbe.SolutionBorder;
import holder.vis.InstancePointConverter;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class KPSMapDisplay<P extends GenericProblemInstance, S extends GenericSolution> extends JPanel implements ActionListener, InstancePointConverter {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private Set<SolutionBorder> borders;
	private Rectangle region;
	private final Map<SolutionBorder,Boolean> borderStatus = new HashMap<SolutionBorder,Boolean>();
	private boolean fullview = false;
	private boolean psmapView = false;
	private boolean averageIntersect = false;
	private int scale;
	private int offset;
	private GenericPSMap<P,S> psmap;
	private Solution drawnSolution;
	private Point instancePointClicked;
	private ProblemSpaceAdapter<P> psAdapter;

	private static final Color[] colors = new Color[]{Color.red.darker(), Color.blue.darker(), Color.gray.darker(), Color.black.darker(), Color.magenta.darker(), Color.orange.darker()};
	static int nextNewColor = 0;
	private static final Map<GenericSolution, Color> solutionColor = new HashMap<GenericSolution, Color>();
	private static final Rectangle DEFAULT_PROBLEM_SPACE_REGION = new Rectangle(1,1,100,100);


	public void drawSolution(Solution s, Point instancePoint){
		drawnSolution = s;
		instancePointClicked = instancePoint;
		repaint();
	}


	@Override
	public void actionPerformed(ActionEvent ev){
		//JComponent comp = (JComponent)ev.getSource();
		JCheckBox comp = (JCheckBox) ev.getSource();

		if (comp.getClientProperty(KBorderSelector.FULLVIEW) != null){
			fullview = comp.isSelected();//!fullview;
		}
		else if(comp.getClientProperty(KBorderSelector.PSMAPVIEW) != null){
			psmapView = comp.isSelected();//!psmapView;
		}
		else{

			SolutionBorder border = (SolutionBorder)comp.getClientProperty(KBorderSelector.BORDER);
			if (border != null){
				//borderStatus.put(border, !borderStatus.get(border));
				borderStatus.put(border, comp.isSelected());
			}
		}

		if (comp.getClientProperty(KBorderSelector.AVERAGE_INTERSECT) != null){
			averageIntersect = !averageIntersect;
		}
		repaint();
	}




	public KPSMapDisplay(Set<SolutionBorder> b, Rectangle r, GenericPSMap p, ProblemSpaceAdapter<P> psAdapter){
		init(b,r,p,psAdapter);
	}
	private void init(Set<SolutionBorder> b, Rectangle r, GenericPSMap psmap, ProblemSpaceAdapter<P> psAdapter){
		this.borders = b;

		if (borders != null){
			for (SolutionBorder border : borders){
				borderStatus.put(border, Boolean.FALSE);
			}
		}

		this.region = r;
		this.scale = 5;

		if (region == null){
			region = DEFAULT_PROBLEM_SPACE_REGION;
			System.out.println("PSMapDisplay: problem space region=" + region);
		}
		this.offset = Math.max(0,Math.max(-region.x,-region.y))+10;

		this.psmap = psmap;
		this.psAdapter = psAdapter;


	}




	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);

		doPsmapView(g);
//		if (fullview){
//			doFullView(g);
//		}
//		else if(psmapView){
//			doPsmapView(g);
//		}
//		else{
//			doBorderView(g);
//		}

		g.setColor(Color.black);
		g.drawRect(scale*(region.x+offset), scale*(region.y+offset), scale*region.width, scale*region.height);

		if (drawnSolution != null){
			for (int i = 1; i < drawnSolution.getFixedPoints().size(); i++){

				Point begin = drawnSolution.getFixedPoints().get(i-1);
				Point end = drawnSolution.getFixedPoints().get(i);
				if (begin == null) begin = instancePointClicked;
				if (end == null) end = instancePointClicked;
				g.setColor(Color.black);
				g.drawLine(convertInstancePointToGraphicPoint(begin.x),
						convertInstancePointToGraphicPoint(begin.y),
						convertInstancePointToGraphicPoint(end.x),
						convertInstancePointToGraphicPoint(end.y));

			}
		}//end if drawn solution
		drawInstancePoint(g,instancePointClicked);

		Object obj = psmap.getMetadata(KPSMapSolveOrApprox.TAG);
		if (obj instanceof DisplayAugmenter<?>){
			DisplayAugmenter<P> displayA = (DisplayAugmenter<P>) obj;
			if (displayA != null){
				displayA.draw(g, this, psAdapter);
			}
		}

	}

/**
 * map from a point to the the problem instance that generates it
 */
	private final Map<Point,P> p2pi = new HashMap<Point,P>();

	private void doPsmapView(Graphics g) {
		if (this.psmap == null) return;



		for (Map.Entry<P, S> entry : psmap.entrySet()){
			P pi = entry.getKey();
			Point p = this.psAdapter.getInstancePoint(pi);
			S s = entry.getValue();

			p2pi.put(p,pi);

			Color c = solutionColor.get(s);
			if (c == null){
				c = colors[nextNewColor];
				nextNewColor = (nextNewColor + 1) % colors.length;
				solutionColor.put(s,c);
				//System.out.println(getClass().getName() + ".doPsmapView: Solution,solutionColor = " + s.toString() + "," + solutionColor);
			}
			drawBigPoint(g,p,c);
		}

		/*ArrayList<Point> fixedPoints = psmap.getFixedPoints();
		for (Point p : fixedPoints){
			drawBigPoint(g,p,Color.black);
		}
		drawOriginPoint(g);*/


	}

	private void doFullView(Graphics g){

		//we'll compare the solutions contained in the first SolutionBorder we find
		SolutionBorder border = null;
		for(Map.Entry<SolutionBorder,Boolean> entry : borderStatus.entrySet()){
			if (entry.getValue() == true){
				border = entry.getKey();
				break;
			}
		}

		if (border == null) {
			return;
		}

		Solution solA = border.getSolution();
		Solution solB = border.getNeighborSolution();

		Set<Point> blackPoints = new HashSet<Point>();
		for (int heightI = 0; heightI < region.height; heightI++){
			for (int widthI = 0; widthI < region.width; widthI++){
				Color color;
				Point p = new Point(region.x + widthI, region.y + heightI);
				if (solA.isBetterThan(solB,p)){
					color = Color.green;
					drawPoint(g,p,color);
				}
				else if (solB.isBetterThan(solA,p)){
					color = Color.red;
					drawPoint(g,p,color);
				}
				else{
					blackPoints.add(p);
				}


			}//end width
		}//end heightI

		//draw black points last so they appear on top
		for (Point p : blackPoints){
			drawPoint(g,p,Color.black);
		}

		//draw fixed points
		for (Point p : solA.getFixedPoints()){
			if (p != null){
				g.setColor(Color.black);
				g.fillOval(convertInstancePointToGraphicPoint(p.x), convertInstancePointToGraphicPoint(p.y), 4,4);
			}
		}

	}

	private int convertInstancePointToGraphicPoint(int i){
		return scale*(i+offset);
	}

	public Point convertInstancePointToGraphicPoint(Point instancePoint){
		return new Point( convertInstancePointToGraphicPoint(instancePoint.x),
				          convertInstancePointToGraphicPoint(instancePoint.y));
	}
	public Point convertGraphicPointToInstancePoint(Point graphicPoint){
		return new Point(   graphicPoint.x/scale-offset,
							graphicPoint.y/scale-offset  );
	}

	private void drawPoint(Graphics g,Point instancePoint, Color color){
		g.setColor(color);
		g.fillOval(convertInstancePointToGraphicPoint(instancePoint.x), convertInstancePointToGraphicPoint(instancePoint.y), 2,2);
	}

	private void drawBigPoint(Graphics g,Point p, Color color){
		g.setColor(color);
		g.fillOval(convertInstancePointToGraphicPoint(p.x), convertInstancePointToGraphicPoint(p.y), 4,4);
	}

	private void drawOriginPoint(Graphics g){
		g.setColor(Color.black);
		g.drawOval(convertInstancePointToGraphicPoint(0), convertInstancePointToGraphicPoint(0), 4, 4);
	}
	private void drawInstancePoint(Graphics g, Point p){
		System.out.println(getClass().getName() + ".drawInstancePoint: drawing instance point " + p);
		if (p != null){
			g.setColor(Color.black);
			g.drawRect(convertInstancePointToGraphicPoint(p.x), convertInstancePointToGraphicPoint(p.y), 4, 4);
		}

	}

	private void doBorderView(Graphics g){

		if (this.borders == null) return;

		int colorI = 0;

		List<SolutionBorder> selectedBorders = new ArrayList<SolutionBorder>();
		for (SolutionBorder cpoints : this.borders){
			if (borderStatus.get(cpoints)){ //if this one is turned on
				selectedBorders.add(cpoints);
			}
		}

		//	    List<BorderIntersection> bInts = new ArrayList<BorderIntersection>();
		//	    for (int i = 0; i < selectedBorders.size(); i++){
		//	    	for (int j = i+1; j < selectedBorders.size(); j++){
		//	    		bInts.addAll(BorderIntersection.getIntersections(selectedBorders.get(i),selectedBorders.get(j)));
		//	    	}
		//	    }

		Set<BorderIntersection> bInts = PSMapCalculator.findBorderIntersections(selectedBorders);

		//draw regular points
		for (SolutionBorder border : selectedBorders){
			for (Point p : border){
				//draw regular point
				drawPoint(g,p,colors[colorI]);
				colorI = (colorI + 1) % colors.length;
			}
		}


		for (BorderIntersection b : bInts){
			g.setColor(Color.black);
			if (this.averageIntersect){
				g.setColor(Color.black);
				g.fillOval(convertInstancePointToGraphicPoint(b.intersectionPoint.x),convertInstancePointToGraphicPoint(b.intersectionPoint.y),4,4);
			}
			else{

				for (Point p : b.intersectionPoints){
					g.fillOval(convertInstancePointToGraphicPoint(p.x),convertInstancePointToGraphicPoint(p.y),4,4);
				}
			}

		}//end for each BorderIntersection


	}//end method doBorderView

	class CanvasMouseListener extends MouseAdapter{

		JLabel statusLabel;
		public CanvasMouseListener(JLabel statusLabel){

			this.statusLabel = statusLabel;
		}

		@Override
		public void mouseClicked(MouseEvent evt){
			Point p = convertGraphicPointToInstancePoint(evt.getPoint());
			P pi = p2pi.get(p);
			S s = psmap.get(pi);
			statusLabel.setText("<html>ProblemInstance at " + p + " -> " + s +
								"<br>Utility: " + (s==null?"null":s.getUtility(pi)) + "</html>");

			//PSMapDisplay canvas = (PSMapDisplay)evt.getComponent();
			//canvas.drawSolution(s,p);
		}
	}
	/**
	 * converts a problem instance to its location in the problem space
	 * @author holderh1
	 *
	 */
	public interface ProblemSpaceAdapter<P extends GenericProblemInstance>{
		public Point getInstancePoint(P pi);
	}

	public interface DisplayAugmenter<P extends GenericProblemInstance>{
		public void draw(Graphics g, InstancePointConverter iConverter, ProblemSpaceAdapter<P> psAdapter);
	}
}
