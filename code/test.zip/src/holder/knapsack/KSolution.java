package holder.knapsack;

import holder.GenericProblemInstance;
import holder.GenericSolution;
import hu.pj.obj.Item;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class KSolution extends GenericSolution {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public Map<String,Item> items = new HashMap<String,Item>();

	public KSolution(Collection<Item> items) {
		for (Item item : items){
			this.items.put(item.getName(), item);
		}
	}

	@Override
	public boolean equals(Object o) {
		if (o == null) return false;
		if (this == o) return true;
		if (!(o instanceof KSolution)){
			return false;
		}
		KSolution other = (KSolution)o;
		if (other.items.size() != this.items.size()){
			return false;
		}
		for (String name : this.items.keySet()){
			Item otherItem = other.items.get(name);
			if (otherItem == null ||
					otherItem.getInKnapsack() != this.items.get(name).getInKnapsack()){
				return false;
			}
		}
		return true;
	}

	/**
	 * find value of a configuration of item quantity (the solution) with respect
	 * to a configuration of item values (problem instance).  To avoid divide by zero
	 * errors in evaluation functions that calculate % utility different, the minimum
	 * value returned is 1.
	 */
	@Override
	public double getUtility(GenericProblemInstance gpi) {
		int utility = 0;

		for (Object obj : gpi.values()){
			if (obj instanceof Item){
				Item i = (Item)obj;

				Item solutionItem = items.get(i.getName());
				int count = solutionItem==null?0:solutionItem.getInKnapsack();
				utility += i.getValue()*count;

			}
		}

		if (BatchK.feasCheckMode == BatchK.FeasibilityCheckMode.NONE){
			return 1+utility;
		}
		else{
			return 1 + (isFeasible(gpi)? utility : 0);
		}
	}

	public int getTotalWeight(GenericProblemInstance gpi){
		int weight = 0;
		for (Object obj : gpi.values()){
			if (obj instanceof Item){
				Item i = (Item)obj;
				Item solutionItem = items.get(i.getName());
				int solutionItemCount;
				if (solutionItem == null){
					solutionItemCount = 0;
					System.out.println(getClass().getName()+".getTotalWeight: null solution item: " + i.getName());
				}
				else{
					solutionItemCount = solutionItem.getInKnapsack();
				}
				weight += i.getWeight()*solutionItemCount;
			}
		}
		return weight;
	}


	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		int hashCode = 0;
		for (Item item : items.values()){
			hashCode += item.getInKnapsack();
		}
		return hashCode;
	}

	@Override
	public String toString(){
		StringBuffer sb = new StringBuffer("KSolution[items=");
		for (Item i : items.values()){
			if (i.getInKnapsack()>0) sb.append(i.toString() + ",");
		}
		return sb.toString();
	}



	@Override
	public boolean isFeasible(GenericProblemInstance gpi) {
		int weight = this.getTotalWeight(gpi);
		int maxWeight = (Integer)gpi.get(KProblemInstance.WEIGHT);
		return weight <= maxWeight;
	}
}
