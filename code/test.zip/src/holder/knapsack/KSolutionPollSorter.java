package holder.knapsack;

import holder.GenericSolution;

import java.util.Comparator;
import java.util.Map;

public class KSolutionPollSorter<S extends GenericSolution> implements Comparator<S> {

		Map<S,Double> poll;

		KSolutionPollSorter(final Map<S,Double> poll){
			this.poll = poll;
		}

		@Override
		public int compare(S arg0, S arg1) {
			return (int) (poll.get(arg1) - poll.get(arg0));
		}
}

