package holder.knapsack;

import holder.GenericProblemSpace;
import holder.PSDimension;
import holder.util.Domain;
import hu.pj.obj.Item;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

public class KProblemSpace extends GenericProblemSpace<KProblemInstance> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public KProblemSpace(KProblemInstance template){
		super(template);
	}

	@Override
	public KProblemInstance generateInstance(KProblemInstance template, KProblemInstance prev, GenericProblemSpace<KProblemInstance> gps, Map<String,Object> domainMap){
		KProblemInstance newP = (KProblemInstance)template.clone();
		int weight = (Integer)domainMap.get(KProblemInstance.WEIGHT);
		int value = (Integer)domainMap.get(KProblemInstance.VALUE);
		Item item = new Item(KProblemInstance.VARIABLE, weight, value);
		newP.put(KProblemInstance.VARIABLE,item);
		return newP;
	}

	/**
	 * @param args
	 */
	public static void main(String[] arg){
		Domain[] domains = new Domain[]{new Domain(KProblemInstance.WEIGHT, Arrays.asList(new Integer[]{2,3,5,7})),
										//new Domain("integerInc", 3, 9, 2),
										new Domain(KProblemInstance.VALUE, 3, 9, 2)};


		//GenericProblemSpace<KProblemInstance> gps = new GenericProblemSpace<KProblemInstance>(new KProblemInstance(Arrays.asList(new Item("x",1,1), new Item("y",2,3)),40));
		KProblemSpace gps = new KProblemSpace(new KProblemInstance(new ArrayList<Item>(),40));

		for (Domain d : domains){
			gps.put(new PSDimension(d.label,d));
		}

		int index = 0;
		for (KProblemInstance gpi : gps){
			System.out.println(index++ + ": " + gpi);
		}

	}


}
