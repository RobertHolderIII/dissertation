package holder;

public class GenericProblemSpaceAnalysis {
	public GenericPSMap psmap;
}
