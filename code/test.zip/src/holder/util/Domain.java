package holder.util;



import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class Domain implements Iterable<Object>{
	public static enum Type{RANGE, LIST};
	public String label;
	public Type type;
	public int min;
	public int max;
	public int inc;
	public Double multiplier;

	public List<?> list;

	public Domain(String label, int min, int max, int inc){
		this(label, min, max, inc, null);
	}

	public Domain(String label, int min, int max, int inc, Double multiplier){
		this.label = label;
		this.min = min;
		this.max = max;
		this.inc = inc;
		this.multiplier = multiplier;
		this.type = Type.RANGE;
	}

	public Domain(String label,List<?> list){
		this.label = label;
		this.list = list;
		this.type = Type.LIST;
	}

	/**
	 * iterator over the valid values in this Domain
	 * @return
	 */
	@Override
	public Iterator<Object> iterator(){
		return new DomainIterator(this);
	}

	public static void main(String[] arg){
		Domain listDomain = new Domain("list", Arrays.asList(new String[]{"a","b","c","d"}));
		Domain integerInc = new Domain("integerInc", 3, 9, 2);
		Domain integerMult = new Domain("integerMult", 3, 9, 2, .001);

		Domain[] allDomains = new Domain[]{listDomain, integerInc, integerMult};

		for (Domain d : allDomains){
			for (Object o : d){
				System.out.print(o + " ");
			}
			System.out.println();
		}

		for (Domain d : allDomains){
			System.out.println(d.label + " has " + d.getInstanceCount() + " items");
		}
	}


	private class DomainIterator implements Iterator<Object>{
		Iterator<?> i;
		private final Domain domain;
		private int current;

		public DomainIterator(Domain d){
			this.domain = d;
			if (domain.type == Type.LIST){
				i = domain.list.iterator();
			}
			else{
				current = domain.min;
			}
		}

		@Override
		public boolean hasNext() {
			if (domain.type == Type.LIST){
				return i.hasNext();
			}
			else{
				return current <= domain.max;
			}
		}

		@Override
		public Object next() {
			if (domain.type == Type.LIST){
				return i.next();
			}
			else{
				if (current > domain.max){
					throw new NoSuchElementException();
				}
				else{
					Object retVal;
					if (domain.multiplier == null){
						retVal = new Integer(current);
					}
					else{
						retVal = new Double(current * domain.multiplier);
					}
					current += domain.inc;
					return retVal;
				}
			}
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException();
		}

	}//end class DomainIterator


	public int getInstanceCount() {
		if (type == Type.LIST){
			return list.size();
		}
		else{
			return (max-min)/inc + 1;
		}

	}

}