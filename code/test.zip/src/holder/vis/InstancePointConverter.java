package holder.vis;

import java.awt.Point;

public interface InstancePointConverter {
	public Point convertInstancePointToGraphicPoint(Point instancePoint);
}
