package holder.sbe;

import holder.PSMap;
import holder.util.TSPSolver;
import holder.util.Util;

import java.io.File;
import java.util.Date;

import javax.swing.JFileChooser;

public class BatchSBE {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFileChooser chooser = new JFileChooser(Util.DATA_DIR);
		chooser.setMultiSelectionEnabled(true);
		
		int returnVal = chooser.showOpenDialog(null);
		if(returnVal != JFileChooser.APPROVE_OPTION) System.exit(0);
		File[] idealPsmapFiles = chooser.getSelectedFiles();

		final double INITIAL_SAMPLE_RATE = .006;//.001;
		final double MAX_SAMPLE_RATE = .101;
		final double INC_SAMPLE_RATE  = .005;
		for (double sampleRate = INITIAL_SAMPLE_RATE; sampleRate <= MAX_SAMPLE_RATE; sampleRate+=INC_SAMPLE_RATE){
			for (File idealPsmapFile : idealPsmapFiles){
				System.out.println("[" + new Date() + "]Approximating " + idealPsmapFile + " at rate " + sampleRate);
				PSMap ideal = Util.loadPSMap(idealPsmapFile);
				TSPSolver solver = new TSPSolver();
				PSMapCalculator calc = new PSMapCalculator(solver);
				
				long startTime = System.currentTimeMillis();
				PSMap sbePsmap = calc.generatePSMap(sampleRate, ideal.getProblemSpace(), ideal.getFixedPoints());
				sbePsmap.setTimeStarted(startTime);
				sbePsmap.markEnd();
				
				String sbeMapFname = "sbe-" + (sampleRate*1000) + "-" + idealPsmapFile.getName();
				File sbeMapFile = new File(idealPsmapFile.getParentFile(), sbeMapFname);
				Util.savePSMap(sbePsmap, sbeMapFile);
				System.out.println("[" + new Date() + "]Wrote SBE approx map to " + sbeMapFile + 
									" (" + solver.getNumberOfProblemInstancesSolved()+ " TSPs solved; " + 
									sbePsmap.getTimeToCreateInSeconds() +" seconds)"); 
			}
		}//end for each sample rate
			

	}

}
