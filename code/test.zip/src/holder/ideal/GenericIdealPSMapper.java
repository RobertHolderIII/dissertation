package holder.ideal;

import holder.GenericPSMap;
import holder.GenericProblemInstance;
import holder.GenericSolution;
import holder.Solver;
import holder.knapsack.KProblemInstance;
import holder.knapsack.KSolution;
import holder.log.MyLogger;
import holder.util.GenericUtil;

import java.io.File;
import java.util.Collection;

public class GenericIdealPSMapper<P extends GenericProblemInstance,S extends GenericSolution>{

	private static final long MAX_MILLS_BEWTEEN_SAVES = 5 * 60 * 1000; //5 minutes
	private File incrementalSaveFile = null;
	private boolean dirty = false;
	private long lastSave = -1;


	public void setIncrementalSaveFile(File f){
		this.incrementalSaveFile = f;

	}


	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		Point[] four = new Point[]{new Point(-20,-20), new Point(-5, -5), new Point(0, 10), new Point(-20, 5)};
//		Point[] nine = new Point[]{new Point(-20,-20), new Point(-5, -5), new Point(0, 10), new Point(-20, 5),
//					  			  new Point(40,5), new Point(-30, 20), new Point(-20, 30), new Point(30,20),
//					  			  new Point(45,-30)};
//
//		GenericIdealPSMapper ideal = new GenericIdealPSMapper();
//
//		GenericProblemSpace gps = new GenericProblemSpace(){{
//			put("test", new Domain(1,10,1));
//		}};
//
//		GenericSolver gs = new GenericSolver(){
//
//			@Override
//			public GenericSolution getSolution(
//					GenericProblemInstance problemInstance) {
//				// TODO Auto-generated method stub
//				return null;
//			}
//
//		};
//
//		GenericPSMap psmap = ideal.generatePSMap(gps, gs);
//
//		Visualizer v = new Visualizer();
//		v.setVisible(true);
//		v.display(psmap.getProblemSpace(), psmap.borders, psmap, "IdealPSMapper test");
//
//		//File dataDir = Util.DATA_DIR;
//		//Util.savePSMap(psmap, new File(dataDir, "psmap-test.ser"));
//
//	}

	private GenericPSMap initializeSaveFile(){
		GenericPSMap psmap;
		File ifn = incrementalSaveFile;//==null?"null":incrementalSaveFile.getAbsolutePath();
		System.out.println("PSMap.generatePSMap: incrementalSaveFile = " + ifn);

		if (incrementalSaveFile != null && incrementalSaveFile.exists()){
			log("IdealPSMapper.generatePSMap: loading previous incremental save file from " + incrementalSaveFile.getAbsolutePath());
			psmap = GenericUtil.loadPSMap(incrementalSaveFile);
			log("IdealPSMapper.generatePSMap: loaded " + psmap.size() + " previously computed instances from " + incrementalSaveFile.getAbsolutePath());
			log("IdealPSMapper.generatePSMap: using fixed points in file");
		}
		else{
			log("IdealPSMapper.generatePSMap: No increment file found.  starting from scratch");
			psmap = new GenericPSMap();
			dirty = true;
			doIncrementalSave(psmap); //doing this one to find out quickly if saving is a problem
		}
		lastSave = System.currentTimeMillis();
		return psmap;
	}

	/*public GenericPSMap generatePSMap(GenericProblemSpace problemSpace, GenericSolver solver){
		//either loads previously saved incremental save or returns empty psmap
		GenericPSMap psmap = initializeSaveFile();



	}*/
	//map save functionality adapted from http://www.javafaq.nu/java-example-code-193.html
	public GenericPSMap<P,S> generatePSMap(Collection<P> problemInstances, Solver<P,S> solver){

		//TODO hack
		int hasVar = 0;
		int tot = 0;
		final boolean doHack = false;
		//hack

		//either loads previously saved incremental save or returns empty psmap
		GenericPSMap psmap = initializeSaveFile();

		for (P pi : problemInstances)	{

			if (!psmap.containsKey(pi)){
				S solution = solver.getSolution(pi);
				psmap.put(pi, solution);
				dirty = true;

				//TODO hack
				if (doHack){
					tot++;
					KSolution ks = (KSolution)solution;
					if (((KSolution)solution).items.get(KProblemInstance.VARIABLE).getInKnapsack()>0){
						hasVar++;
					}
				}
				//end hack

			}
			else{
				System.out.println("GenericIdealPSMapper: skipping problem instance " + pi);
			}

			//incremental save
			if ( (System.currentTimeMillis() - lastSave) > MAX_MILLS_BEWTEEN_SAVES ){
				doIncrementalSave(psmap);
			}

		}//end for each GPI

		//TODO hack
		if (doHack){
			System.out.println("GenericIdealPSMapper: solution hasVar/tot = " + hasVar + "/" + tot);
		}
		//end hack

		return psmap;
	}

	private void doIncrementalSave(GenericPSMap psmap){
		if (incrementalSaveFile != null && dirty){
			GenericUtil.savePSMap(psmap, incrementalSaveFile);
			lastSave = System.currentTimeMillis();
			log("IdealPSMapper.doIncrementalSave: saved " + psmap.size() + " instances  to " + incrementalSaveFile.getAbsolutePath());
		}
	}

	public void deleteIncrementalFile() {
		if (incrementalSaveFile != null){
			incrementalSaveFile.delete();
		}
	}

	private void log(String s){
		MyLogger.getInstance().info(s);
	}
}
