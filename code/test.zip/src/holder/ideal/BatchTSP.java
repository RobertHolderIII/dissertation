package holder.ideal;

import holder.PSMap;
import holder.Solver;
import holder.util.TSPSolver;
import holder.util.Util;

import java.awt.Point;
import java.awt.Rectangle;
import java.io.File;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import holder.log.MyLogger;

public class BatchTSP {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final boolean saveIncrementally = false;
		
		IdealPSMapper mapper = new IdealPSMapper();
		Solver solver = new TSPSolver();
		
		int[] tspSizes;
		Rectangle region;
		
		boolean small = true;
		if (small){
			tspSizes = new int[]{5,10,20,50,100};
			region = new Rectangle(0,0,15,15);
		}
		else{
			tspSizes = new int[]{5,10,20,50,100};
			region = new Rectangle(-40,-40,90,90);
		}
		
		
		final int numberOfUnknownLocations = 2;
		final int numberOfInstancesPerConfiguration = 3;
		
		for (int i = 0; i < numberOfInstancesPerConfiguration; i++){
			for (int tspSize : tspSizes){
				
				//format is psmap-<tsp|<#>vrp>-<R|C|RC>-[unk<numberOfUnknowns>-]instance<#>.ser
				String fname = "psmap-tsp-" + tspSize + "-R-" + "unk" + numberOfUnknownLocations + "-instance" + i + ".ser";
				File outFile = new File(Util.DATA_DIR, fname );
				
				//save incrementally
				if (saveIncrementally){
					String incFname = fname + ".part";
					mapper.setIncrementalSaveFile(new File(Util.DATA_DIR, incFname));
				}				
								
				MyLogger.log("====>BatchTSP: Generating TSP size " + tspSize);
				MyLogger.log("saving to " + outFile.getAbsolutePath());
				
				//generate random points for R-type problem instance
				Point[] fixedPoints = generateRandomFixedPoints(region, tspSize-numberOfUnknownLocations);
				
				//do the hard work
				PSMap psmap = mapper.generatePSMap(region, solver, fixedPoints);
				Util.savePSMap(psmap, outFile);
				outFile.setReadOnly();
				mapper.deleteIncrementalFile();
				
			}
		}
		
	}//end main

	public static Point[] generateRandomFixedPoints(Rectangle region, int count){
		Random rand = new Random();
		
		Point[] fixedPoints = new Point[count];
		
		Set<Point> points = new HashSet<Point>();
		
		//do it this way so duplicate points get thrown away
		while(points.size() < count){
			Point randPoint = new Point(region.x + rand.nextInt(region.width),
					   region.y + rand.nextInt(region.height));
			if (!randPoint.equals(Util.ORIGIN)){
				points.add(randPoint);
			}
		}
		
		points.toArray(fixedPoints);
		return fixedPoints;
	
	}

	public static Point[] generateClusteredFixedPoints(Rectangle region, int count){
		Random rand = new Random();
		
		Point[] fixedPoints = new Point[count];
		
		Set<Point> points = new HashSet<Point>();
		
		//do it this way so duplicate points get thrown away
		while(points.size() < count){
			Point randPoint = new Point(region.x + rand.nextInt(region.width),
					   region.y + rand.nextInt(region.height));
			if (!randPoint.equals(Util.ORIGIN)){
				points.add(randPoint);
			}
		}
		
		points.toArray(fixedPoints);
		return fixedPoints;
	
	}
	
}
